import pyautogui
import pygetwindow as gw
import time
from datetime import datetime

# ========= CTRL SERIES (tuple form) =========
ctrl_time_series = (3, 2, 4)    # minutes
ctrl_click_series = (2, 3, 4)   # clicks

# ========= TAB SERIES (tuple form) =========
tab_time_series = (3, 2, 4)     # minutes (1 tab per step)
# ==========================================
# IMPORTANT: ctrl_time_series and ctrl_click_series must have the SAME length.

if len(ctrl_time_series) != len(ctrl_click_series):
    raise SystemExit("ctrl_time_series and ctrl_click_series must be the same length "
                     "(use 05_decoupled_series.py for different lengths).")


def focus_chrome():
    windows = gw.getWindowsWithTitle('Chrome')
    if windows:
        chrome = windows[0]
        if chrome.isMinimized:
            chrome.restore()
        chrome.activate()
        time.sleep(1)
        return True
    return False


print("=== CTRL + TAB COUPLED SERIES SCRIPT STARTED ===")
print("Units: minutes | Press CTRL + C to stop\n")

ctrl_step = 0
tab_step = 0
last_ctrl_time = time.time()
last_tab_time = time.time()

while True:
    time.sleep(1)
    now_ts = time.time()

    # -------- CTRL SERIES --------
    ctrl_wait_min = ctrl_time_series[ctrl_step]
    ctrl_clicks = ctrl_click_series[ctrl_step]

    if now_ts - last_ctrl_time >= ctrl_wait_min * 60:
        now = datetime.now().strftime("%H:%M:%S")
        print(f"[{now}] Ctrl START -> {ctrl_clicks} times (after {ctrl_wait_min} min)")
        for i in range(ctrl_clicks):
            pyautogui.keyDown('ctrl')
            time.sleep(0.1)
            pyautogui.keyUp('ctrl')
            print(f"   Ctrl press #{i+1}")
            time.sleep(0.2)
        print(f"[{now}] Ctrl END\n")
        last_ctrl_time = now_ts
        ctrl_step = (ctrl_step + 1) % len(ctrl_time_series)

    # -------- TAB SERIES --------
    tab_wait_min = tab_time_series[tab_step]

    if now_ts - last_tab_time >= tab_wait_min * 60:
        if focus_chrome():
            pyautogui.hotkey('ctrl', 'tab')
            tab_time = datetime.now().strftime("%H:%M:%S")
            print(f"[{tab_time}] TAB CHANGED (after {tab_wait_min} min)\n")
        else:
            print("Chrome not found\n")
        last_tab_time = now_ts
        tab_step = (tab_step + 1) % len(tab_time_series)
