import pyautogui
import time
from datetime import datetime

# ========= SERIES CONFIG =========
# (minutes, ctrl_press_count)
series = [
    (2, 3),   # wait 2 min -> Ctrl x3
    (5, 4),   # wait 5 min -> Ctrl x4
]
# ================================

print("=== CTRL SERIES SCRIPT STARTED ===")
print("Press CTRL + C to stop\n")

step = 0
while True:
    minutes, press_count = series[step]
    print(f"Waiting {minutes} minutes...")
    time.sleep(minutes * 60)

    now = datetime.now().strftime("%H:%M:%S")
    print(f"[{now}] Ctrl press START ({press_count} times)")
    for i in range(press_count):
        pyautogui.keyDown('ctrl')
        time.sleep(0.1)
        pyautogui.keyUp('ctrl')
        print(f"   Ctrl press #{i+1}")
        time.sleep(0.2)
    print(f"[{now}] Ctrl press END\n")

    step = (step + 1) % len(series)
