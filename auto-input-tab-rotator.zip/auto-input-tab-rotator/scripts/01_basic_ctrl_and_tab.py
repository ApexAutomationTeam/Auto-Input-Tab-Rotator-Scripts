import pyautogui
import pygetwindow as gw
import time
from datetime import datetime

# ================= SETTINGS =================
CTRL_INTERVAL = 20         # seconds between Ctrl bursts
CTRL_PRESS_COUNT = 3       # Ctrl presses per burst
TEST_TAB_DELAY = 60        # seconds before the one-time test run
TEST_TAB_CHANGES = 3       # tab switches during the test run
NORMAL_TAB_INTERVAL = 480  # seconds between tab switches (8 min)
# ===========================================

script_start = time.time()
last_tab_change = None
test_done = False


def focus_chrome():
    windows = gw.getWindowsWithTitle('Chrome')
    if windows:
        chrome = windows[0]
        if chrome.isMinimized:
            chrome.restore()
        chrome.activate()
        time.sleep(1)
        return True
    return False


print("=== AUTO CTRL + CHROME TAB SCRIPT STARTED ===")
print("Keep the target Chrome window in front (not minimized)")
print("Press CTRL + C to stop\n")

while True:
    time.sleep(CTRL_INTERVAL)

    # -------- CTRL PRESS --------
    now = datetime.now().strftime("%H:%M:%S")
    print(f"[{now}] Ctrl press start")
    for i in range(CTRL_PRESS_COUNT):
        pyautogui.keyDown('ctrl')
        time.sleep(0.1)
        pyautogui.keyUp('ctrl')
        time.sleep(0.2)

    current_time = time.time()

    # -------- TEST MODE (runs once) --------
    if not test_done and current_time - script_start >= TEST_TAB_DELAY:
        print("TEST MODE: focusing Chrome")
        if focus_chrome():
            for i in range(TEST_TAB_CHANGES):
                pyautogui.hotkey('ctrl', 'tab')
                print(f"   Test tab change #{i+1}")
                time.sleep(1)
        else:
            print("Chrome window NOT found")
        test_done = True
        last_tab_change = time.time()
        print("TEST MODE DONE\n")

    # -------- NORMAL MODE --------
    if test_done and time.time() - last_tab_change >= NORMAL_TAB_INTERVAL:
        if focus_chrome():
            pyautogui.hotkey('ctrl', 'tab')
            print("NORMAL MODE: Chrome tab changed\n")
        else:
            print("Chrome window NOT found\n")
        last_tab_change = time.time()
