import pyautogui
import pygetwindow as gw
import time
from datetime import datetime

# ========= CTRL SETTINGS =========
CTRL_INTERVAL = 20
CTRL_PRESS_COUNT = 3

# ========= TAB SERIES (minutes) =========
tab_time_series = [2, 5, 3]   # any number of entries; only the timing changes
# ========================================


def focus_chrome():
    windows = gw.getWindowsWithTitle('Chrome')
    if windows:
        chrome = windows[0]
        if chrome.isMinimized:
            chrome.restore()
        chrome.activate()
        time.sleep(1)
        return True
    return False


print("=== CTRL + TAB SERIES SCRIPT STARTED ===")
print("Rule: exactly 1 tab change each time")
print("Press CTRL + C to stop\n")

tab_step = 0
last_tab_time = time.time()

while True:
    # -------- CTRL PRESS --------
    time.sleep(CTRL_INTERVAL)
    now = datetime.now().strftime("%H:%M:%S")
    print(f"[{now}] Ctrl press ({CTRL_PRESS_COUNT}x)")
    for i in range(CTRL_PRESS_COUNT):
        pyautogui.keyDown('ctrl')
        time.sleep(0.1)
        pyautogui.keyUp('ctrl')
        time.sleep(0.2)

    # -------- TAB SERIES --------
    wait_minutes = tab_time_series[tab_step]
    wait_seconds = wait_minutes * 60

    if time.time() - last_tab_time >= wait_seconds:
        if focus_chrome():
            pyautogui.hotkey('ctrl', 'tab')
            tab_time = datetime.now().strftime("%H:%M:%S")
            print(f"[{tab_time}] TAB CHANGED (after {wait_minutes} min)")
        else:
            print("Chrome not found")
        last_tab_time = time.time()
        tab_step = (tab_step + 1) % len(tab_time_series)
