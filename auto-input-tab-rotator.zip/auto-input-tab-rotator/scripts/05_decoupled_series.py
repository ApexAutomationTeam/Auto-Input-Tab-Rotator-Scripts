import pyautogui
import pygetwindow as gw
import time
from datetime import datetime

# ========= CTRL (INDEPENDENT SERIES) =========
ctrl_time_series = (3, 2)       # minutes
ctrl_click_series = (2, 3, 4)   # clicks (length may differ)

# ========= TAB (INDEPENDENT SERIES) =========
tab_time_series = (5, 10, 13)   # minutes (1 tab per step)
# ============================================


def focus_chrome():
    windows = gw.getWindowsWithTitle('Chrome')
    if windows:
        chrome = windows[0]
        if chrome.isMinimized:
            chrome.restore()
        chrome.activate()
        time.sleep(1)
        return True
    return False


print("=== CTRL + TAB DECOUPLED SERIES SCRIPT STARTED ===")
print("Ctrl timing, Ctrl click count and tab timing all cycle independently")
print("Units: minutes | Press CTRL + C to stop\n")

ctrl_time_step = 0
ctrl_click_step = 0
last_ctrl_time = time.time()

tab_step = 0
last_tab_time = time.time()

while True:
    time.sleep(1)
    now_ts = time.time()

    # -------- CTRL LOGIC --------
    ctrl_wait_min = ctrl_time_series[ctrl_time_step]
    ctrl_clicks = ctrl_click_series[ctrl_click_step]

    if now_ts - last_ctrl_time >= ctrl_wait_min * 60:
        now = datetime.now().strftime("%H:%M:%S")
        print(f"[{now}] Ctrl START -> {ctrl_clicks} times (after {ctrl_wait_min} min)")
        for i in range(ctrl_clicks):
            pyautogui.keyDown('ctrl')
            time.sleep(0.1)
            pyautogui.keyUp('ctrl')
            print(f"   Ctrl press #{i+1}")
            time.sleep(0.2)
        print(f"[{now}] Ctrl END\n")
        last_ctrl_time = now_ts
        ctrl_time_step = (ctrl_time_step + 1) % len(ctrl_time_series)
        ctrl_click_step = (ctrl_click_step + 1) % len(ctrl_click_series)

    # -------- TAB LOGIC --------
    tab_wait_min = tab_time_series[tab_step]

    if now_ts - last_tab_time >= tab_wait_min * 60:
        if focus_chrome():
            pyautogui.hotkey('ctrl', 'tab')
            tab_time = datetime.now().strftime("%H:%M:%S")
            print(f"[{tab_time}] TAB CHANGED (after {tab_wait_min} min)\n")
        else:
            print("Chrome not found\n")
        last_tab_time = now_ts
        tab_step = (tab_step + 1) % len(tab_time_series)
